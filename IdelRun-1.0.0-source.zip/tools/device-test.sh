#!/usr/bin/env bash
set -euo pipefail
mkdir -p device-check
adb shell wm size 720x1440
adb shell wm density 280
adb install -r download/IdelRun-1.0.0.apk
adb shell am start -W -n ru.idelrun.game/.MainActivity
sleep 5
adb shell pidof ru.idelrun.game
adb exec-out screencap -p > device-check/home.png
adb shell uiautomator dump /sdcard/window.xml
adb pull /sdcard/window.xml device-check/home.xml
python3 - <<'PY'
import xml.etree.ElementTree as E,re,subprocess
root=E.parse('device-check/home.xml')
for n in root.iter('node'):
    if 'БЕЖАТЬ' in (n.get('text','')+' '+n.get('content-desc','')) and n.get('clickable')=='true':
        x,y,r,b=map(int,re.findall(r'\d+',n.get('bounds')))
        subprocess.run(['adb','shell','input','tap',str((x+r)//2),str((y+b)//2)],check=True)
        break
else:
    subprocess.run(['adb','shell','input','tap','360','1256'],check=True)
PY
sleep 1
adb shell input swipe 470 820 245 820 120
adb shell input swipe 360 920 360 605 120
adb exec-out screencap -p > device-check/run.png
adb shell input keyevent 4
sleep 1
adb shell uiautomator dump /sdcard/window.xml
adb pull /sdcard/window.xml device-check/after.xml
adb logcat -d -s AndroidRuntime:E chromium:E > device-check/errors.log
! grep -q 'FATAL EXCEPTION' device-check/errors.log
python3 - <<'PY'
import xml.etree.ElementTree as E
root=E.parse('device-check/after.xml')
text=' '.join(str(n.attrib) for n in root.iter('node'))
assert 'ПРОДОЛЖИТЬ' in text or 'Пауза' in text, 'The run did not reach the pause dialog'
PY
