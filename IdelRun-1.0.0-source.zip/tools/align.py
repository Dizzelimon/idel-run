"""Place uncompressed data, including the resource table, at 4-byte boundaries."""
import struct
import sys
from pathlib import Path
from zipfile import ZipFile, ZipInfo, ZIP_STORED

src, dex, dst = map(Path, sys.argv[1:])
with ZipFile(src) as old, ZipFile(dst, "w") as out:
    entries = [(i.filename, old.read(i), i.compress_type) for i in old.infolist()]
    entries.append(("classes.dex", dex.read_bytes(), ZIP_STORED))
    for name, data, method in entries:
        info = ZipInfo(name)
        info.compress_type = method
        if method == ZIP_STORED:
            offset = out.fp.tell() + 30 + len(name.encode())
            padding = (-offset) % 4
            if padding:
                info.extra = struct.pack("<HH", 0xCAFE, padding) + bytes(padding)
        out.writestr(info, data)
