#!/usr/bin/env bash
# Linux x86_64, Java 17+, zip/unzip, Python 3. Use the Android SDK's apksigner or APK_SIGNER_JAR.
set -euo pipefail
root=$(cd "$(dirname "$0")/.." && pwd)
: "${APKTOOL_JAR:?Set APKTOOL_JAR to Apktool 2.9.3}"
: "${KEYSTORE:?Set KEYSTORE to the private signing keystore}"
: "${STORE_PASS:?Set STORE_PASS to its password}"
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
mkdir -p "$tmp/dex" "$root/download"
cp -r "$root/android/smali" "$root/android/apktool.yml" "$tmp/dex/"
java -jar "$APKTOOL_JAR" b "$tmp/dex" -o "$tmp/dex.apk"
unzip -p "$tmp/dex.apk" classes.dex > "$tmp/classes.dex"
unzip -p "$APKTOOL_JAR" prebuilt/linux/aapt_64 > "$tmp/aapt"
chmod +x "$tmp/aapt"
unzip -p "$APKTOOL_JAR" brut/androlib/android-framework.jar > "$tmp/framework.jar"
"$tmp/aapt" package -f -M "$root/android/AndroidManifest.xml" -I "$tmp/framework.jar" -S "$root/android/res" -A "$root/www" -F "$tmp/base.apk"
python3 "$root/tools/align.py" "$tmp/base.apk" "$tmp/classes.dex" "$tmp/aligned.apk"
signer=(apksigner)
if [[ -n "${APK_SIGNER_JAR:-}" ]]; then signer=(java -jar "$APK_SIGNER_JAR"); fi
out="$root/download/IdelRun-1.0.0.apk"
"${signer[@]}" sign --ks "$KEYSTORE" --ks-key-alias "${KEY_ALIAS:-idel}" --ks-pass env:STORE_PASS --v4-signing-enabled false --out "$out" "$tmp/aligned.apk"
"${signer[@]}" verify --verbose "$out"
"$tmp/aapt" dump badging "$out" | head -9
