.class public Lru/idelrun/game/MainActivity;
.super Landroid/app/Activity;

.field private web:Landroid/webkit/WebView;

.method public constructor <init>()V
    .locals 0
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 3
    invoke-super {p0,p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V
    new-instance v0, Landroid/webkit/WebView;
    invoke-direct {v0,p0}, Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V
    iput-object v0,p0,Lru/idelrun/game/MainActivity;->web:Landroid/webkit/WebView;
    invoke-virtual {v0}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;
    move-result-object v1
    const/4 v2,1
    invoke-virtual {v1,v2}, Landroid/webkit/WebSettings;->setJavaScriptEnabled(Z)V
    invoke-virtual {v1,v2}, Landroid/webkit/WebSettings;->setDomStorageEnabled(Z)V
    invoke-virtual {p0,v0}, Landroid/app/Activity;->setContentView(Landroid/view/View;)V
    const/16 v1,0x1706
    invoke-virtual {v0,v1}, Landroid/view/View;->setSystemUiVisibility(I)V
    const-string v1,"file:///android_asset/index.html"
    invoke-virtual {v0,v1}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V
    return-void
.end method

.method protected onPause()V
    .locals 3
    iget-object v0,p0,Lru/idelrun/game/MainActivity;->web:Landroid/webkit/WebView;
    const-string v1,"window.backgroundGame && window.backgroundGame()"
    const/4 v2,0
    invoke-virtual {v0,v1,v2}, Landroid/webkit/WebView;->evaluateJavascript(Ljava/lang/String;Landroid/webkit/ValueCallback;)V
    invoke-virtual {v0}, Landroid/webkit/WebView;->onPause()V
    invoke-super {p0}, Landroid/app/Activity;->onPause()V
    return-void
.end method

.method protected onResume()V
    .locals 1
    invoke-super {p0}, Landroid/app/Activity;->onResume()V
    iget-object v0,p0,Lru/idelrun/game/MainActivity;->web:Landroid/webkit/WebView;
    invoke-virtual {v0}, Landroid/webkit/WebView;->onResume()V
    return-void
.end method

.method public onBackPressed()V
    .locals 3
    iget-object v0,p0,Lru/idelrun/game/MainActivity;->web:Landroid/webkit/WebView;
    const-string v1,"window.backGame && window.backGame()"
    const/4 v2,0
    invoke-virtual {v0,v1,v2}, Landroid/webkit/WebView;->evaluateJavascript(Ljava/lang/String;Landroid/webkit/ValueCallback;)V
    return-void
.end method
