const World=(()=>{
  const {group,box,ball,cyl,torus,strand,bake}=Art,T=THREE;
  const zones=[
    {name:'Казань',sub:'Кремлёвская набережная',tatar:'КАЗАН',code:'KZN',top:'#58b8cb',bottom:'#ffe4ac',ground:'#a96e64',tree:'#39947c',building:'#e9ba87',roof:'#477e92'},
    {name:'Свияжск',sub:'Остров-град',tatar:'ЗӨЯ',code:'SVY',top:'#80bfcc',bottom:'#ffe2ae',ground:'#ae806f',tree:'#799b53',building:'#bc8064',roof:'#528b70'},
    {name:'Мамадыш',sub:'Набережная Вятки',tatar:'МАМАДЫШ',code:'MMD',top:'#a899cb',bottom:'#ffd3a0',ground:'#a16c79',tree:'#548c80',building:'#e8aa8a',roof:'#687daa'}
  ];
  const templ={};
  function make(key,fn){if(!templ[key]){const g=group();fn(g);templ[key]=bake(g);}return templ[key].clone();}
  function tree(g,x,z,k,size){
    const p=group(g,x,0,z);p.scale.setScalar(size);cyl(p,'#885c50',0,1.22,0,.12,.24,2.44,7);
    for(const [xx,yy,r] of [[0,3,1.26],[-.62,2.54,.88],[.63,2.66,.92]]){const t=cyl(p,k,xx,yy,0,.48*r,r,1.6*r,7);t.rotation.y=xx;}
  }
  function windowRow(p,x,y,z,count,step){
    for(let k=0;k<count;k++){const zz=z+k*step;box(p,'#fff1c7',x,y,zz,.14,1.28,.90);box(p,'#396078',x+(x<0?-.08:.08),y+.01,zz,.08,.99,.69);box(p,'#eabf91',x+(x<0?-.13:.13),y+.04,zz,.04,.065,.70);}
  }
  function house(g,x,z,zone,v){
    const p=group(g,x,0,z),side=-Math.sign(x),w=4.2,h=3.45+v*.8,d=6.7;
    box(p,zone.building,0,h/2,0,w,h,d);box(p,'#fff0c8',0,.33,0,w+.27,.5,d+.28);
    box(p,zone.roof,0,h+.23,0,w+.48,.48,d+.55);box(p,'#f2d0a1',0,h-.23,0,w+.16,.23,d+.18);
    const roof=cyl(p,zone.roof,0,h+.79,0,0,1,1.24,4,0,Math.PI/4);roof.scale.set(3.20,1,4.97);
    windowRow(p,side*2.1,1.8,-2.25,4,1.5);if(v>1)windowRow(p,side*2.1,3.42,-2.25,4,1.5);
    box(p,'#ac7967',1.02,h+1.01,-1,.47,1.65,.52);
  }
  function minaret(g,x,z,h){
    cyl(g,'#f5d9ad',x,h*.42,z,.38,.65,h*.84,8);cyl(g,'#68a3a3',x,h*.66,z,.62,.59,.28,8);
    cyl(g,'#fff0c3',x,h*.84,z,.47,.53,.76,8);cyl(g,'#32899e',x,h*.96,z,0,.58,h*.25,8);
    cyl(g,'#f8c65a',x,h*1.11,z,0,.07,.70,6);
  }
  function mosque(g,x,z,scale=1){
    const p=group(g,x,0,z);p.scale.setScalar(scale);
    box(p,'#ffe8bb',0,2.27,0,5.3,4.54,4.3);cyl(p,'#e5cba3',0,4.7,0,2,2.65,1.0,8);
    ball(p,'#3894a9',0,5.07,0,2.18,1.72,2.18);cyl(p,'#fbd478',0,6.95,0,0,.135,1.20,8);
    for(let i=-1;i<=1;i++){box(p,'#42788a',i*1.50,2.18,2.17,.77,2.3,.095);ball(p,'#42788a',i*1.50,3.31,2.19,.39,.49,.06);}
    for(const s of [-1,1])for(const u of [-1,1])minaret(p,s*2.98,u*2.36,8.3);
  }
  function church(g,x,z){
    const p=group(g,x,0,z);box(p,'#f3d8ae',0,2.05,0,4.7,4.1,4.5);box(p,'#6d9388',0,4.14,0,5,.33,4.8);
    for(const [xx,zz,h,r] of [[0,0,6.1,1.15],[-1.65,1.55,5,.55],[1.65,1.55,5,.55],[-1.65,-1.55,5,.55],[1.65,-1.55,5,.55]]){
      cyl(p,'#f5d9a0',xx,h-.86,zz,r*.75,r*.85,1.6,12);ball(p,'#548577',xx,h+.04,zz,r,r*.95,r);cyl(p,'#547d6c',xx,h+r,zz,0,r*.62,r*1.02,10);strand(p,'#e5bc6a',[xx,h+r*1.34,zz],[xx,h+r*1.94,zz],.052);box(p,'#e5bc6a',xx,h+r*1.74,zz,r*.43,.073,.075);
    }
  }
  function riverTower(g,x,z){
    const p=group(g,x,0,z);for(let i=0;i<4;i++){const r=1.65-i*.33;for(const a of [-1,1])for(const b of [-1,1]){
      strand(p,'#7e5960',[a*r,i*1.7,b*r],[a*(r-.33),(i+1)*1.7,b*(r-.33)],.09);
      strand(p,'#a87866',[a*r,i*1.7,b*r],[-a*(r-.33),(i+1)*1.7,b*(r-.33)],.049);}
      box(p,'#99695e',0,(i+1)*1.7,0,(r-.23)*2,.13,(r-.23)*2);}
    cyl(p,'#805c62',0,7.38,0,0,.25,1.38,8);
  }
  function section(zoneId,variant){
    return make('sec'+zoneId+variant,g=>{
      const q=zones[zoneId];
      box(g,q.ground,0,-.36,-12,15,.64,24.02);
      for(const l of [-1,0,1]){let x=l*2.5;
        box(g,'#9a7670',x,-.034,-12,2.15,.08,24);
        for(let n=0;n<16;n++)box(g,n%3?'#765a57':'#896861',x,.017,-n*1.5-.6,1.94,.10,.32);
        for(const s of [-1,1]){box(g,'#5b5b6b',x+s*.69,.083,-12,.15,.15,24);box(g,'#dfc5ac',x+s*.69,.17,-12,.095,.036,24);}
      }
      for(const s of [-1,1]){
        box(g,'#d6aa8a',s*5.20,.18,-12,2.15,.48,24);box(g,'#f7d3a2',s*4.18,.46,-12,.21,.12,24);
        const riverSide=s===1 && zoneId!==1;
        if(riverSide){box(g,'#5ba9b3',s*19,-.15,-12,26,.20,24.05);
          for(let i=0;i<6;i++)box(g,'#8dc7c2',9+((i*9+variant*7)%18),-.037,-i*3.7,1+(i%3),.02,.12);
          for(let i=0;i<5;i++)cyl(g,'#527472',6.1,.96,-i*5.4,.09,.13,1.45,6);
          box(g,'#628480',6.1,1.59,-12,.1,.1,24);
        }else{
          house(g,s*10.45,-6,q,variant%3);if(variant!==1)house(g,s*12,-18,q,(variant+1)%3);
          for(let i=0;i<2;i++)tree(g,s*(6.85+i*.3),-2-i*13.5-variant,q.tree,1+variant*.07);
        }
      }
      if(variant===1){const x=-5.15;box(g,'#456573',x,3.70,-12,.16,7.4,.20);box(g,'#526d79',0,7.36,-12,10.4,.19,.18);
        box(g,'#667884',5.15,3.7,-12,.15,7.4,.17);
        for(let i=-1;i<=1;i++)box(g,'#b0a28b',i*2.5,7.07,-12,.08,.44,.08);
      }else{
        const x=variant===0?5.25:-5.25;cyl(g,'#4c626d',x,2.64,-8,.078,.14,4.67,8);
        box(g,'#3e5262',x,5.01,-8,.57,.14,.57);ball(g,'#fff1a0',x,4.82,-8,.21,.26,.21);
      }
      if(variant===2){if(zoneId===0)mosque(g,17,-18,1.13);if(zoneId===1)church(g,16,-14);if(zoneId===2)riverTower(g,-7.7,-18);}
    });
  }
  function train(tone){
    return make('train'+tone,g=>{
      const primary=tone?'#e16453':'#277d91',dark='#2c4659',cream='#ffe3ad';
      box(g,'#384554',0,.46,-4.6,1.92,.68,9.15);
      box(g,primary,0,1.55,-4.66,2.04,2.13,9.18);box(g,cream,0,2.24,-4.66,2.08,.93,9.16);
      box(g,'#82a6aa',0,2.85,-4.65,2.09,.27,9.32);
      box(g,'#587483',0,3.02,-4.85,1.52,.09,5.15);
      box(g,dark,0,2.24,-.02,1.76,.68,.18,.10);
      for(const s of [-1,1]){box(g,'#8dbbc5',s*.428,2.28,.073,.75,.45,.03,.10);
        box(g,'#fff2a6',s*.68,1.23,.019,.35,.19,.12);box(g,'#c8c5af',s*.66,.72,.05,.43,.12,.15);
        for(let i=0;i<6;i++){box(g,dark,s*1.055,2.22,-.86-i*1.47,.042,.64,.93);box(g,'#8cbcc6',s*1.079,2.25,-.86-i*1.47,.025,.47,.80);}
        box(g,'#fac668',s*1.04,1.52,-4.63,.045,.13,9.15);}
      box(g,'#394453',0,.49,.12,1.57,.24,.24);
      box(g,'#fff4c9',0,1.76,.06,1.82,.11,.10);box(g,primary,0,2.77,.023,.84,.23,.12);
      for(let j=0;j<5;j++)box(g,'#ffe299',-.23+j*.118,2.77,.092,.067,.072,.02);
    });
  }
  function ramp(){return make('ramp',g=>{
    const len=8.0,high=2.98,angle=Math.atan(high/len);
    box(g,'#bd8a51',0,high/2,-len/2,2.0,.16,Math.hypot(len,high),angle);
    for(let i=0;i<10;i++){let z=(i+.4)/10*len;box(g,'#f2c673',0,z/len*high+.09,-z,1.9,.075,.14,angle);}
    for(const s of [-1,1])strand(g,'#985f4d',[s*.99,.1,0],[s*.99,high+.14,-len],.075);
  });}
  function barrier(overhead){
    return make('bar'+overhead,g=>{
      for(const s of [-1,1]){box(g,'#ffe0a3',s*.84,overhead?1.28:.51,0,.15,overhead?2.56:1.02,.27);box(g,'#475d66',s*.84,.19,0,.34,.38,.49);}
      const y=overhead?1.94:.82,h=overhead?.86:.63;
      box(g,'#984b49',0,y,-.04,1.96,h+.10,.31);box(g,'#fcedc4',0,y,.129,1.89,h,.041);
      for(let i=-1;i<=1;i++)box(g,'#e26350',i*.60,y,.158,.28,h*.96,.036,0,0,-.38);
      if(overhead){for(const s of [-1,1])ball(g,'#ffca52',s*.83,2.52,0,.096,.1,.097);}
    });
  }
  function coin(){return make('coin',g=>{cyl(g,'#d39432',0,0,0,.317,.317,.104,18,Math.PI/2);
    cyl(g,'#ffd05a',0,0,.057,.274,.274,.021,18,Math.PI/2);
    torus(g,'#ffec98',0,0,.073,.244,.014);
    for(const s of [-1,1])ball(g,'#e7a338',s*.063,.015,.082,.061,.12,.019,0,0,-s*.49);
    box(g,'#e7a338',0,-.09,.083,.027,.13,.025);});}
  function token(kind){return make(kind,g=>{
    cyl(g,({magnet:'#ac4f78',double:'#447e91',jet:'#ac6554',spring:'#41876d'})[kind],0,0,0,.43,.43,.18,8,Math.PI/2);
    torus(g,'#ffe8a1',0,0,.11,.345,.03);
    if(kind==='magnet'){torus(g,'#ff7b65',0,0,.16,.145,.057);box(g,'#ac4f78',0,.13,.19,.16,.15,.12);
      for(const s of [-1,1])box(g,'#f6f0ca',s*.13,.13,.17,.085,.14,.06);}
    else if(kind==='jet'){ball(g,'#fff1c7',0,.04,.17,.10,.21,.04,0,0,-.4);for(const s of [-1,1])box(g,'#f2a858',s*.1,-.07,.18,.08,.14,.04,0,0,-.4);}
    else if(kind==='spring'){box(g,'#fff1cf',0,-.08,.17,.35,.11,.04);box(g,'#ffe092',-.09,.014,.18,.14,.17,.04,0,0,-.20);}
    else {for(const s of [-1,1])box(g,'#ffdf67',s*.035,.0,.18,.08,.39,.05,0,0,s*.60);}
  });}
  function board(){return make('board',g=>{ball(g,'#257a72',0,.02,0,.34,.078,.72);box(g,'#ebc775',0,.091,0,.093,.016,1.10);for(const s of [-1,1])ball(g,'#ffb54d',s*.22,-.04,.36,.083,.081,.16);});}
  function jetpack(){return make('rocketpack',g=>{
    box(g,'#efb455',0,.03,0,.37,.48,.22);
    for(const s of [-1,1]){cyl(g,'#428d93',s*.23,0,0,.14,.15,.54,12);ball(g,'#ffdf92',s*.23,.27,0,.14,.14,.14);cyl(g,'#36576b',s*.23,-.27,0,.15,.105,.14,12);cyl(g,'#ffad50',s*.23,-.48,0,.09,0,.35,8);}
  });}
  const panels=[];
  function sign(id){
    if(!panels[id]){
      const q=zones[id],cv=document.createElement('canvas');cv.width=384;cv.height=128;const c=cv.getContext('2d');
      c.fillStyle='#134e55';c.fillRect(0,0,384,128);c.fillStyle='#e6b365';c.fillRect(5,5,374,3);c.fillRect(5,119,374,3);
      c.fillStyle='#ffeac0';c.textAlign='center';c.font='bold 43px sans-serif';c.fillText(q.tatar,192,69);
      c.font='bold 18px sans-serif';c.fillText('ЛИНИЯ 116    /    '+q.code,192,99);
      const tex=new T.CanvasTexture(cv);tex.colorSpace=T.SRGBColorSpace;const p=group();
      const frame=group(p);box(frame,'#405f65',0,0,0,2.85,.97,.16);for(const x of [-1.04,1.04])box(frame,'#466d70',x,-1.08,0,.10,1.8,.11);bake(frame);
      const face=new T.Mesh(new T.PlaneGeometry(2.73,.87),new T.MeshBasicMaterial({map:tex}));face.position.z=.086;p.add(face);panels[id]=p;
    }return panels[id].clone();
  }
  return {zones,section,train,ramp,barrier,coin,token,board,jetpack,sign};
})();
