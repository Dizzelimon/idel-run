(()=>{
  'use strict';
  const $=id=>document.getElementById(id),app=$('app'),zones=World.zones;
  const paths={
    back:'<path d="m14 5-7 7 7 7m-6-7h13"/>',pause:'<path d="M8 5v14m8-14v14" stroke-width="4"/>',
    shop:'<path d="M3 10h18l-2-6H5l-2 6Zm2 1v9h14v-9M9 20v-6h5v6M3 10q2 4 5 0 3 4 6 0 4 4 7 0"/>',
    map:'<path d="m3 5 6-2 6 3 6-2v15l-6 2-6-3-6 2V5Zm6-2v15m6-12v15"/>',
    sound:'<path d="M3 10h4l5-5v14l-5-5H3v-4Zm13-2q4 4 0 8m3-11q7 7 0 14"/>',
    mute:'<path d="M3 10h4l5-5v14l-5-5H3v-4Zm13-1 5 6m0-6-5 6"/>',
    coin:'<circle cx="12" cy="12" r="10" fill="#ffc857" stroke="#b78440"/><circle cx="12" cy="12" r="7.4" stroke="#ffe6a0"/><path d="M12 16V9m0 4q-4 0-4-4 3 0 4 4Zm0 0q4 0 4-4-3 0-4 4" stroke="#a36b34"/>',
    hat:'<path d="M3 15 5 8q7-4 14 0l2 7q-8 4-18 0Z" fill="#338574"/><path d="m5 13 3 1 2-2 3 2 2-2 3 1" stroke="#ffd96c"/>',
    scarf:'<path d="m3 6 4-2q5 3 11 0l3 3-4 5-2 9-4-1 2-9-7 1Z" fill="#df6954"/><path d="m13 17 3 1"/>',
    bag:'<path d="M7 7V6q0-5 6-4 4 0 4 5m-13 4q0-5 7-5h3q6 0 6 5v8q-1 3-6 3H8q-4 0-4-3Z" fill="#438c80"/><path d="M8 14h9v5H8Z" fill="#e6a563"/>',
    glasses:'<path d="m2 9 2 7q4 3 7-3l2-1q3 7 7 4l2-7-9 1-2 0Z" fill="#526e7b"/><path d="m5 10 2-1m8 2 2-1" stroke="#ffde96"/>',
    board:'<path d="M2 14q0-3 3-4l14-3q4-1 3 3-1 3-4 4L5 17q-3 0-3-3Z" fill="#85c4a2"/><path d="m6 18 1 1m10-4 1 1" stroke="#ffca62"/>'
  };
  function icon(name){return '<svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">'+paths[name]+'</svg>';}
  document.querySelectorAll('[data-icon]').forEach(x=>x.innerHTML=icon(x.dataset.icon));
  const items=[['hat','Тюбетейка','Головной убор',30],['scarf','Алый шарф','Шарф',45],['bag','Рюкзак «Идел»','Рюкзак',75],['glasses','Очки «Закат»','Очки',100]];
  const key='idel.run.v1';let data={bank:0,best:0,owned:[],wear:[],station:0,sound:true,recordScore:0};
  try{let d=JSON.parse(localStorage.getItem(key)||'{}');Object.assign(data,d);for(const k of ['owned','wear'])data[k]=Array.isArray(data[k])?data[k].filter(id=>items.some(it=>it[0]===id)):[];for(const k of ['bank','best','recordScore'])data[k]=Math.max(0,Math.floor(Number(data[k])||0));data.station=[0,1,2].includes(data.station)?data.station:0;}catch{}
  const save=()=>{try{localStorage.setItem(key,JSON.stringify(data));}catch{}};
  const fresh=()=>({lane:0,x:0,y:0,vy:0,roof:false,slide:0,dist:0,score:0,cash:0,speed:12.3,phase:0,board:0,boards:1,magnet:0,double:0,jet:0,spring:0,grace:0,zone:data.station,objects:[],next:22,row:0,time:0});
  let s=fresh(),mode='home',selection=0,stationAt=0,toastUntil=0,oldTime=0,uiTime=0,random=Math.random,zoneStep=285;
  function screen(v){mode=v;app.className=({paused:'paused',over:'over',running:'running'})[v]||v;}
  function sync(){document.querySelectorAll('.balance').forEach(n=>n.innerHTML='<i>'+icon('coin')+'</i><b>'+data.bank+'</b>');document.querySelectorAll('.best').forEach(n=>n.textContent=data.best+' м');
    document.querySelectorAll('.sound').forEach(b=>{b.innerHTML=icon(data.sound?'sound':'mute')+(b.classList.contains('secondary')?' Музыка '+(data.sound?'вкл.':'выкл.'):'');b.setAttribute('aria-label',data.sound?'Выключить музыку':'Включить музыку');b.setAttribute('aria-pressed',String(data.sound));});Music.set(data.sound);}
  function home(){screen('home');Music.stop();Visual.clear();Visual.dress(data.wear);sync();}
  function start(){s=fresh();Visual.clear();Visual.dress(data.wear);Visual.setZone(s.zone);screen('running');stationAt=2.4;toastUntil=0;$('toast').textContent='';Music.start();buildAhead();hud();banner();oldTime=performance.now();}
  function banner(){const b=$('station');b.querySelector('strong').textContent=zones[s.zone].name;b.querySelector('em').textContent=zones[s.zone].sub;b.style.opacity=1;}
  function tell(str){$('toast').textContent=str;toastUntil=s.time+1.3;}
  function pause(){if(mode!=='running')return;screen('paused');save();Music.stop();}
  function resume(){if(mode!=='paused')return;screen('running');Music.start();oldTime=performance.now();}
  function finish(impact){if(mode!=='running'&&mode!=='paused')return;const d=Math.floor(s.dist),prev=data.best;
    data.best=Math.max(d,data.best);data.recordScore=Math.max(data.recordScore,Math.floor(s.score));save();screen('over');if(impact)Music.sfx('crash');
    setTimeout(()=>{if(mode==='over')Music.stop();},320);$('finalDistance').textContent=d+' м';$('finalCoins').textContent='+'+s.cash+' монет';$('finalScore').textContent=Math.floor(s.score)+' очков';
    $('record').textContent=d>prev?'Новый рекорд!':'Рекорд · '+data.best+' м';$('finishStation').textContent=zones[s.zone].name.toUpperCase()+'  /  ЛИНИЯ 116';sync();}
  function action(a){
    if(a==='start'){start();return;}if(a==='home'){home();return;}if(a==='shop'){screen('shop');s.zone=data.station;Visual.setZone(s.zone);selection=0;shopUI();return;}if(a==='map'){screen('map');mapUI();return;}
    if(a==='pause')pause();if(a==='resume')resume();if(a==='leave')finish(false);if(mode!=='running')return;
    if(a==='left'||a==='right'){s.lane=THREE.MathUtils.clamp(s.lane+(a==='left'?-1:1),-1,1);}
    if(a==='up'&&(s.y<=.025||s.roof)){s.slide=0;s.roof=false;s.vy=s.spring>0?12.25:9.2;s.y+=.035;Music.sfx('jump');}
    if(a==='down'&&s.jet<=0){s.slide=.83;if(s.y>.05&&!s.roof)s.vy=Math.min(s.vy,-12);}
    if(a==='board'){if(s.boards&&s.board<=0){s.boards--;s.board=11;Music.sfx('power');tell('Доска · один удар под защитой');}else if(s.board<=0)tell('Доска появится в новом забеге');}
  }
  function push(kind,lane,d,height=0,opts={}){s.objects.push(Object.assign({kind,lane,d,height,seed:random()*Math.PI*2},opts));}
  function coins(l,d,n,height=1.05,spacing=2.45){for(let i=0;i<n;i++)push('coin',l,d+i*spacing,height);}
  function buildAhead(){
    const lanes=[-1,0,1];while(s.next-s.dist<123){const d=s.next-s.dist,r=s.row++,l=r===0?0:Math.floor(random()*3)-1,other=lanes.filter(v=>v!==l),safe=other[Math.floor(random()*2)];
      let pattern=r<5?r:[0,1,2,3,4,5,6][Math.floor(random()*7)];
      if(pattern===0){push('low',l,d);coins(l,d-3.1,3,1.52,1.65);coins(safe,d+5.5,4);}
      if(pattern===1){push('train',l,d,0,{color:r%2,move:r>6&&r%3===0?2.6:0});coins(safe,d-3.8,7);}
      if(pattern===2){push('high',l,d);coins(l,d,4,.52,2.3);if(r>5)push('low',other[0],d);}
      if(pattern===3){push('ramp',l,d);push('train',l,d+8,0,{color:1,move:0});for(let j=0;j<5;j++)push('coin',l,d+j*1.52,.82+j*.57);coins(l,d+8.6,4,3.90,2.19);coins(safe,d+3,4);}
      if(pattern===4){push('train',l,d,0,{color:r%2,move:0});push('low',other[0],d+2);coins(other[1],d-2,6);}
      if(pattern===5){push('high',l,d);push('train',other[0],d+1,0,{color:1,move:0});coins(other[1],d-1,5);}
      if(pattern===6){push('low',l,d);push('low',safe,d+6);coins(other.find(v=>v!==safe),d-1,5);}
      if(r%4===2)push(['magnet','double','jet','spring'][Math.floor(r/4)%4],safe,d+12,1.32);
      s.next+=Math.max(24,2.04*s.speed)+(pattern===3?8:0);
    }
  }
  function lose(o){if(s.grace>0)return;if(s.board>0){s.board=0;s.grace=2.15;o.gone=true;tell('Доска спасла!');Music.sfx('power');return;}finish(true);}
  const pickup=o=>['coin','magnet','double','jet','spring'].includes(o.kind);
  function step(dt){
    s.time+=dt;s.speed=Math.min(24.5,12.3+s.dist*.0095);const delta=s.speed*dt;s.dist+=delta;s.score+=delta*(s.double>0?2:1);
    s.x+=(s.lane-s.x)*(1-Math.exp(-13.5*dt));s.phase+=dt*(10.2+s.speed*.24);
    for(const k of ['slide','board','magnet','double','grace','jet','spring'])s[k]=Math.max(0,s[k]-dt);
    const prevY=s.y;s.vy-=22*dt;s.y+=s.vy*dt;
    if(s.jet>0){s.vy=0;s.y+=(4.90-s.y)*(1-Math.exp(-6*dt));s.slide=0;}
    if(s.y<=0){s.y=0;s.vy=0;}s.roof=false;
    for(const o of s.objects)o.d-=delta+(o.move||0)*dt;
    for(const o of s.objects){if(o.gone||Math.abs(s.x-o.lane)>.55)continue;
      if(o.kind==='ramp'&&o.d<=.23&&o.d>=-8.2){const h=THREE.MathUtils.clamp(-o.d/8*2.99,0,2.99);if(s.vy<=0&&s.y<=h+.26){s.y=h;s.vy=0;s.roof=true;}}
      if(o.kind==='train'&&o.d<=.36&&o.d>=-9.35&&prevY>=2.76&&s.vy<=0&&s.y<=3.11){s.y=3.03;s.vy=0;s.roof=true;}}
    for(const o of s.objects){if(o.gone)continue;const dx=Math.abs(s.x-o.lane);
      if(pickup(o)){
        const magnet=o.kind==='coin'&&s.magnet>0&&Math.abs(o.d)<5.1&&Math.abs(s.y+.95-o.height)<3.6;
        if(!magnet&&(Math.abs(o.d)>.91||dx>.55||Math.abs(s.y+(s.slide?.54:1.13)-o.height)>1.0))continue;
        o.gone=true;if(o.kind==='coin'){s.cash++;data.bank++;s.score+=s.double>0?20:10;save();Music.sfx('coin');}
        else{
          s[o.kind]=o.kind==='jet'?6:o.kind==='magnet'?9:10;
          if(o.kind==='jet')for(let i=0;i<23;i++)push('coin',s.lane,6+i*2.6,5.75);
          Music.sfx('power');tell(({magnet:'Магнит!',double:'Очки ×2!',jet:'Реактивный ранец!',spring:'Высокие прыжки!'})[o.kind]);}continue;
      }
      if(dx>.58||s.grace>0||s.jet>0)continue;
      if(o.kind==='train'&&o.d<=.32&&o.d>=-9.3&&s.y<2.75)lose(o);
      else if(o.kind==='low'&&Math.abs(o.d)<.52&&s.y<1.10)lose(o);
      else if(o.kind==='high'&&Math.abs(o.d)<.48&&s.y<2.49&&!(s.slide>0&&s.y<.20))lose(o);
      if(mode!=='running')break;
    }
    if(mode!=='running')return;
    s.objects=s.objects.filter(o=>!o.gone&&o.d>(o.kind==='train'?-11:o.kind==='ramp'?-9:-2));buildAhead();
    const z=(data.station+Math.floor(s.dist/zoneStep))%3;if(z!==s.zone){s.zone=z;Visual.setZone(z);stationAt=s.time+2.15;banner();}
  }
  function hud(){const dist=Math.floor(s.dist);$('meters').textContent=dist+' м';$('score').textContent=Math.floor(s.score)+' очков';$('pocket').textContent=s.cash;$('station').style.opacity=s.time<stationAt?1:0;
    $('effect').textContent=[s.magnet?'Магнит '+Math.ceil(s.magnet)+' с':'',s.double?'×2 · '+Math.ceil(s.double)+' с':'',s.board?'Доска '+Math.ceil(s.board)+' с':'',s.jet?'Полёт '+Math.ceil(s.jet)+' с':'',s.spring?'Прыжок ↑':''].filter(Boolean).join('  ·  ');
    $('hint').textContent=s.time<3.8?'← →  Меняй путь свайпом':s.time<7?'↑  Прыжок     ↓  Подкат':'';
    if(s.time>toastUntil)$('toast').textContent='';$('deck').style.opacity=s.boards||s.board?1:.5;}
  function shopUI(){
    const [id,name,type,price]=items[selection],owned=data.owned.includes(id),on=data.wear.includes(id);sync();Visual.dress([...new Set([...data.wear,id])]);
    $('items').innerHTML=items.map((it,i)=>'<button class="chip '+(i===selection?'active':'')+'" aria-label="'+it[1]+'" data-item="'+i+'"><i>'+icon(it[0])+'</i></button>').join('');
    $('itemname').textContent=name;$('itemtype').textContent=type.toUpperCase();$('itemindex').textContent=(selection+1)+' / '+items.length;
    $('buy').textContent=owned?(on?'СНЯТЬ':'НАДЕТЬ'):(data.bank>=price?'КУПИТЬ · '+price+' МОНЕТ':'НУЖНО '+price+' МОНЕТ');$('buy').disabled=!owned&&data.bank<price;
  }
  $('buy').onclick=()=>{const [id,,,price]=items[selection];if(data.owned.includes(id)){if(data.wear.includes(id))data.wear=data.wear.filter(v=>v!==id);else data.wear.push(id);}
    else if(data.bank>=price){data.bank-=price;data.owned.push(id);data.wear.push(id);}save();shopUI();Visual.dress(data.wear);};
  function mapUI(){const c=$('mapart').getContext('2d'),w=640,h=335;c.fillStyle='#dfdfbf';c.fillRect(0,0,w,h);
    const curve=(coords,col,width)=>{c.beginPath();c.moveTo(...coords[0]);for(const v of coords.slice(1))c.bezierCurveTo(...v);c.strokeStyle=col;c.lineWidth=width;c.lineCap='round';c.stroke();};
    for(let i=-3;i<18;i++){curve([[i*57,-12],[i*57+58,50,i*57-82,180,i*57+74,353]],'#c5caa9',2);}
    for(let i=0;i<35;i++){let x=(i*113+7)%640,y=(i*71+11)%335;c.fillStyle='#c5d2a9';c.beginPath();c.ellipse(x,y,36,12,-.36,0,7);c.fill();}
    curve([[180,-15],[170,50,116,56,139,111],[194,177,308,132,279,221],[266,279,219,293,244,350]],'#92c5bd',25);
    curve([[650,235],[565,202,527,218,486,230],[417,251,330,219,279,221]],'#92c5bd',19);
    curve([[506,-10],[499,66,549,72,526,111],[505,138,556,170,513,220]],'#92c5bd',13);
    const pts=[[275,111],[102,135],[525,150]];const line=[[102,135],[160,139,207,92,275,111],[345,151,408,93,525,150]];
    curve(line,'#fff5d6',13);curve(line,'#b77054',6);
    c.textAlign='center';c.font='bold 20px sans-serif';zones.forEach((q,i)=>{const [x,y]=pts[i];c.beginPath();c.arc(x,y,i===data.station?13:9,0,7);c.fillStyle=i===data.station?'#f5be4c':'#fff1cd';c.fill();c.strokeStyle='#245650';c.lineWidth=4;c.stroke();c.fillStyle='#214741';c.fillText(q.name,x,y-22);});
    c.font='italic 16px sans-serif';c.fillStyle='#367f7c';c.fillText('Волга',226,278);c.fillText('Кама',409,257);c.fillText('Вятка',557,71);
    c.textAlign='left';c.fillStyle='#345751';c.font='bold 13px sans-serif';c.fillText('СХЕМА МАРШРУТА   /   116',18,310);
    $('stops').innerHTML=zones.map((q,i)=>'<button class="stop '+(i===data.station?'on':'')+'" data-stop="'+i+'"><b>'+q.code+'</b><span>'+q.name+'<em>'+q.sub+'</em></span></button>').join('');
  }
  app.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;if(b.classList.contains('sound')){data.sound=!data.sound;save();sync();if(data.sound&&mode==='running')Music.start();return;}
    if(b.dataset.item!==undefined){selection=Number(b.dataset.item);shopUI();return;}if(b.dataset.stop!==undefined){data.station=Number(b.dataset.stop);save();mapUI();return;}if(b.dataset.action)action(b.dataset.action);});
  let finger=null,lastTap=0;
  app.addEventListener('pointerdown',e=>{if(mode!=='running'||e.target.closest('button')||!e.isPrimary)return;finger={id:e.pointerId,x:e.clientX,y:e.clientY};try{app.setPointerCapture(e.pointerId);}catch{}});
  function swipe(e,ended){if(!finger||e.pointerId!==finger.id)return;const dx=e.clientX-finger.x,dy=e.clientY-finger.y;
    if(Math.max(Math.abs(dx),Math.abs(dy))>Math.max(16,app.clientWidth*.047)){action(Math.abs(dx)>Math.abs(dy)?(dx<0?'left':'right'):(dy<0?'up':'down'));finger=null;lastTap=0;}
    else if(ended){const now=performance.now();if(now-lastTap<315)action('board');lastTap=now;finger=null;}}
  app.addEventListener('pointermove',e=>swipe(e,false));app.addEventListener('pointerup',e=>swipe(e,true));app.addEventListener('pointercancel',()=>finger=null);
  window.backGame=()=>{if(mode==='running')pause();else if(mode==='paused')resume();else home();};
  window.backgroundGame=()=>{if(mode==='running')pause();Music.stop();save();};document.addEventListener('visibilitychange',()=>{if(document.hidden)window.backgroundGame();});
  window.addEventListener('keydown',e=>{const bind={ArrowLeft:'left',KeyA:'left',ArrowRight:'right',KeyD:'right',ArrowUp:'up',KeyW:'up',Space:'up',ArrowDown:'down',KeyS:'down',KeyB:'board'};if(e.repeat)return;
    if(bind[e.code]&&mode==='running'){e.preventDefault();action(bind[e.code]);}else if(e.code==='Escape'||e.code==='KeyP')window.backGame();else if(e.code==='Enter'&&(mode==='home'||mode==='over'))start();});
  function frame(now){const dt=Math.min(.07,Math.max(0,(now-(oldTime||now))/1000));oldTime=now;
    if(mode==='running'){let t=dt;while(t>.00001&&mode==='running'){let sub=Math.min(1/60,t);step(sub);t-=sub;}if(now-uiTime>75){hud();uiTime=now;}}
    if(mode==='running'||mode==='shop'||mode==='paused'||mode==='over')Visual.frame(s,mode==='running'||mode==='shop'?dt:0,mode);
    requestAnimationFrame(frame);}
  home();requestAnimationFrame(frame);
})();
