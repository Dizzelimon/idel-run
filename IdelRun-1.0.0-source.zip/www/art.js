/* Geometry workshop. Rigidly articulated parts use the same palette and lighting as the scenery. */
const Art=(()=>{
  const T=THREE, geo=new Map(), colors=new Map();
  const group=(parent,x=0,y=0,z=0)=>{const g=new T.Group();g.position.set(x,y,z);if(parent)parent.add(g);return g};
  const geoFor=(key,make)=>{if(!geo.has(key))geo.set(key,make());return geo.get(key)};
  const color=c=>{if(!colors.has(c))colors.set(c,new T.Color(c));return colors.get(c)};
  const shader=new T.ShaderMaterial({
    uniforms:{mist:{value:new T.Color('#ffdda9')}},
    vertexShader:`attribute vec3 color; varying vec3 base; varying vec3 norm; varying float depth;
    void main(){base=color;norm=normalize(mat3(modelMatrix)*normal);vec4 p=modelViewMatrix*vec4(position,1.);depth=-p.z;gl_Position=projectionMatrix*p;}`,
    fragmentShader:`varying vec3 base;varying vec3 norm;varying float depth;uniform vec3 mist;
    void main(){vec3 n=normalize(norm);float d=dot(n,normalize(vec3(-.48,.80,.46)));
    float band=.74+.19*smoothstep(-.24,-.12,d)+.15*smoothstep(.48,.58,d);
    vec3 rgb=base*band*mix(vec3(.79,.85,1.),vec3(1.05,1.,.92),smoothstep(-.2,.5,d));
    rgb=mix(rgb,mist,.88*smoothstep(49.,142.,depth));gl_FragColor=vec4(rgb,1.);
    #include <colorspace_fragment>
    }`
  });
  function part(parent,g,c,x,y,z,w,h,d,rx=0,ry=0,rz=0){
    const m=new T.Mesh(g,shader);m.userData.tint=c;m.position.set(x,y,z);m.scale.set(w,h,d);m.rotation.set(rx,ry,rz);parent.add(m);return m;
  }
  const box=(p,c,x,y,z,w,h,d,rx=0,ry=0,rz=0)=>part(p,geoFor('b',()=>new T.BoxGeometry()),c,x,y,z,w,h,d,rx,ry,rz);
  const ball=(p,c,x,y,z,w,h,d,rx=0,ry=0,rz=0)=>part(p,geoFor('s',()=>new T.SphereGeometry(1,16,12)),c,x,y,z,w,h,d,rx,ry,rz);
  const cyl=(p,c,x,y,z,top,bot,h,n=12,rx=0,ry=0,rz=0)=>part(p,geoFor('c'+[top,bot,h,n],()=>new T.CylinderGeometry(top,bot,h,n)),c,x,y,z,1,1,1,rx,ry,rz);
  const torus=(p,c,x,y,z,r,t,rx=0,ry=0,rz=0)=>part(p,geoFor('t'+[r,t],()=>new T.TorusGeometry(r,t,6,24)),c,x,y,z,1,1,1,rx,ry,rz);
  function strand(p,c,a,b,r){
    const v=new T.Vector3(...a),end=new T.Vector3(...b),dir=end.clone().sub(v);
    const mesh=cyl(p,c,0,0,0,r,r,dir.length(),8);mesh.position.copy(v.add(end).multiplyScalar(.5));
    mesh.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),dir.normalize());return mesh;
  }
  // Batch a rigid part into a single vertex-colour mesh. Preserve its pivot for animation.
  function bake(root){
    root.updateWorldMatrix(true,true);const inv=root.matrixWorld.clone().invert(),pos=[],norm=[],rgb=[];
    const pv=new T.Vector3(),nv=new T.Vector3(),mat=new T.Matrix4(),nm=new T.Matrix3();
    root.traverse(o=>{if(!o.isMesh)return;mat.multiplyMatrices(inv,o.matrixWorld);nm.getNormalMatrix(mat);
      const g=o.geometry,ix=g.index,P=g.attributes.position,N=g.attributes.normal,C=g.attributes.color,k=color(o.userData.tint||'#ffffff');
      for(let j=0;j<(ix?ix.count:P.count);j++){const i=ix?ix.getX(j):j;
        pv.fromBufferAttribute(P,i).applyMatrix4(mat);nv.fromBufferAttribute(N,i).applyMatrix3(nm).normalize();
        pos.push(pv.x,pv.y,pv.z);norm.push(nv.x,nv.y,nv.z);if(C)rgb.push(C.getX(i),C.getY(i),C.getZ(i));else rgb.push(k.r,k.g,k.b);}
    });
    root.clear();const g=new T.BufferGeometry();for(const [key,arr] of [['position',pos],['normal',norm],['color',rgb]])g.setAttribute(key,new T.Float32BufferAttribute(arr,3));
    g.computeBoundingSphere();root.add(new T.Mesh(g,shader));return root;
  }
  function hero(){
    const root=group(),body=group(root),torso=group(body,0,.98,0),head=group(body,0,1.91,.025);
    const skin='#d6997f',dark='#302831',navy='#232b48',hood='#a5a9ba',denim='#344054',white='#fff2da',mint='#16856d',gold='#eec471';
    ball(torso,navy,0,.39,0,.385,.52,.25);cyl(torso,navy,0,.11,0,.34,.30,.19);
    ball(torso,white,0,.40,.208,.174,.424,.068);ball(torso,hood,0,.73,-.095,.35,.245,.25);
    ball(torso,'#727b91',0,.735,-.12,.255,.154,.251);
    for(const s of [-1,1]){
      box(torso,white,s*.093,.72,.218,.123,.151,.055,-.20,0,-s*.61);
      strand(torso,gold,[s*.145,.03,.196],[s*.20,.7,.193],.013);
      box(torso,mint,s*.255,.23,.184,.13,.032,.028,0,0,s*.32);
    }
    for(let i=0;i<3;i++)ball(torso,'#d4b8a3',0,.24+.13*i,.278,.016,.016,.01);
    cyl(torso,skin,0,.85,0,.14,.17,.24);bake(torso);
    ball(head,skin,0,.18,.028,.347,.408,.291);
    ball(head,skin,0,.002,.092,.275,.237,.241);
    for(const s of [-1,1]){
      ball(head,skin,s*.337,.15,-.005,.074,.100,.055);ball(head,'#b57b71',s*.371,.153,.037,.030,.055,.015);
      ball(head,'#fff4e2',s*.132,.211,.287,.093,.049,.028,0,s*.27,s*.045);
      ball(head,'#694c37',s*.132,.212,.311,.043,.044,.013);ball(head,'#292633',s*.132,.214,.321,.025,.032,.008);
      ball(head,'#fff9e9',s*.132-.011,.23,.330,.010,.012,.006);
      ball(head,dark,s*.145,.289,.269,.106,.024,.026,0,s*.26,-s*.13);
    }
    ball(head,skin,0,.138,.297,.063,.100,.068);ball(head,'#da987c',0,.092,.327,.077,.044,.058);
    ball(head,'#955f5a',0,-.018,.316,.091,.018,.012,0,0,-.05);
    ball(head,'#d99480',0,-.038,.314,.068,.014,.012);
    // Cropped hairline slopes up at the brow and wraps around the nape.
    const hairGeometry=new T.SphereGeometry(1,28,10,0,Math.PI*2,0,Math.PI*.52);
    const hp=hairGeometry.attributes.position;
    for(let i=0;i<hp.count;i++){const z=hp.getZ(i);hp.setY(i,hp.getY(i)+.45*z*(1-Math.max(0,hp.getY(i))));}hairGeometry.computeVertexNormals();
    part(head,hairGeometry,'#322c32',0,.29,.008,.349,.332,.293);
    for(let i=0;i<15;i++){let a=i*2.399,r=.16*Math.sqrt(i/15);ball(head,'#40383a',Math.sin(a)*r,.586-.43*r,Math.cos(a)*r,.050,.049,.05);}
    bake(head);
    const arms=[],legs=[],knees=[],elbows=[];
    for(const s of [-1,1]){
      const shoulder=group(body,s*.325,1.64,0),upper=group(shoulder);
      ball(upper,navy,s*.058,-.16,0,.139,.247,.141,0,0,s*.16);bake(upper);
      const elbow=group(shoulder,s*.078,-.328,0),fore=group(elbow);
      ball(fore,navy,0,-.126,.012,.120,.18,.12);cyl(fore,mint,0,-.231,.01,.112,.105,.093);
      cyl(fore,white,0,-.238,.01,.111,.108,.018);ball(fore,skin,0,-.330,.044,.112,.14,.102);bake(fore);
      arms.push(shoulder);elbows.push(elbow);
      const hip=group(body,s*.178,1.01,0),thigh=group(hip);
      ball(thigh,denim,0,-.19,.018,.153,.276,.169);bake(thigh);
      const knee=group(hip,0,-.415,.012),lower=group(knee);
      ball(lower,'#35415a',0,-.171,-.008,.132,.223,.132);cyl(lower,'#293348',0,-.317,0,.124,.109,.104);
      ball(lower,white,0,-.422,.074,.158,.10,.231);ball(lower,mint,0,-.392,-.037,.150,.091,.105);
      box(lower,'#edcba1',0,-.481,.061,.286,.055,.36);
      for(let i=0;i<3;i++)box(lower,'#dad5b8',0,-.35-i*.014,.10+i*.033,.104,.019,.019);
      bake(lower);legs.push(hip);knees.push(knee);
    }
    const hat=group(head,0,.46,0);cyl(hat,'#146358',0,.055,0,.298,.345,.174,24);cyl(hat,gold,0,-.009,0,.347,.349,.029,24);
    for(let i=0;i<16;i++){const a=i*Math.PI/8;box(hat,'#ffe197',Math.sin(a)*.324,.056,Math.cos(a)*.324,.046,.047,.017,0,a,.73);}bake(hat);
    const scarf=group(torso);torus(scarf,'#e95142',0,.775,.02,.222,.072,Math.PI/2);
    box(scarf,'#ca3839',-.18,.56,.245,.115,.34,.04,0,0,-.22);bake(scarf);
    const bag=group(torso);ball(bag,'#168c83',0,.39,-.217,.279,.34,.136);ball(bag,'#ef9a51',0,.31,-.329,.213,.15,.047);box(bag,gold,0,.406,-.362,.32,.018,.013);
    for(const s of [-1,1])strand(bag,'#4e676b',[s*.20,.75,.134],[s*.24,.10,.16],.030);bake(bag);
    const glasses=group(head);for(const s of [-1,1]){ball(glasses,'#30455a',s*.14,.211,.305,.119,.072,.028);strand(glasses,gold,[s*.22,.22,.29],[s*.34,.23,.02],.016);}strand(glasses,gold,[-.044,.22,.315],[.044,.22,.315],.014);bake(glasses);
    const gear={hat,scarf,bag,glasses};function dress(ids){for(const k in gear)gear[k].visible=ids.includes(k);}
    dress([]);return {root,body,head,arms,legs,knees,elbows,dress};
  }
  return {group,box,ball,cyl,torus,strand,bake,hero,shader};
})();
