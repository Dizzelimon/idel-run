const Visual=(()=>{
  const T=THREE,canvas=document.getElementById('view'),app=document.getElementById('app');
  let renderer,flat,scene,camera,hero,inspector,board,jetpack,shadow,platform,track=[],zone=-1,clock=0,shop=false;
  let flatGear=[];const meshes=new Map();let pixelRatio=1,slow=0;
  try{renderer=new T.WebGLRenderer({canvas,alpha:true,antialias:true,powerPreference:'high-performance'});}
  catch(e){const next=document.createElement('canvas');next.id='view';canvas.replaceWith(next);flat=next.getContext('2d');}
  if(renderer){
    renderer.setClearColor(0,0);pixelRatio=Math.min(devicePixelRatio||1,1.55);renderer.setPixelRatio(pixelRatio);
    scene=new T.Scene();camera=new T.PerspectiveCamera(57,1,.1,165);
    hero=Art.hero();scene.add(hero.root);inspector=Art.inspector();scene.add(inspector.root);board=World.board();scene.add(board);jetpack=World.jetpack();scene.add(jetpack);
    const disk=new T.CircleGeometry(1,30);disk.rotateX(-Math.PI/2);
    shadow=new T.Mesh(disk,new T.MeshBasicMaterial({color:0x45363c,transparent:true,opacity:.28,depthWrite:false}));scene.add(shadow);
    platform=Art.group(scene);Art.cyl(platform,'#27675e',0,-.16,0,1.45,1.37,.32,48);Art.cyl(platform,'#ffcc65',0,-.03,0,1.46,1.46,.05,48);Art.cyl(platform,'#f1cf98',0,.005,0,1.41,1.41,.045,48);Art.bake(platform);

  }
  function textureSky(q){app.style.background='linear-gradient('+q.top+' 0%, '+q.bottom+' 52%, '+q.ground+' 68%)';}
  function setZone(id){
    if(zone===id)return;zone=id;const q=World.zones[id];textureSky(q);const sky=document.getElementById('skyline');sky.style.backgroundImage='url(sky'+id+'.webp)';sky.style.backgroundPosition=[83,68,77][id]+'% bottom';
    if(!renderer)return;
    Art.shader.uniforms.mist.value.set(q.bottom);for(const p of track)scene.remove(p);track=[];
    for(let i=0;i<7;i++){const p=World.section(id,i%3);scene.add(p);track.push(p);}

    for(let i=1;i<track.length;i+=3){const sign=World.sign(id);sign.position.set(-5.30,2.43,-13);sign.rotation.y=.14;track[i].add(sign);}

  }
  function resize(){const w=app.clientWidth,h=app.clientHeight;if(renderer){renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix();}else{flat.canvas.width=w;flat.canvas.height=h;}}
  window.addEventListener('resize',resize);resize();
  function obj(o){if(o.kind==='coin')return World.coin();if(o.kind==='train')return World.train(o.color);if(o.kind==='ramp')return World.ramp();if(o.kind==='low'||o.kind==='high')return World.barrier(o.kind==='high');return World.token(o.kind);}
  function clear(){if(renderer){for(const v of meshes.values())scene.remove(v);meshes.clear();}}
  function dress(ids){flatGear=ids.slice();if(hero)hero.dress(ids);}
  function pose(s,dt,mode){
    const display=mode==='shop',phase=s.phase;
    hero.root.position.set(display?0:s.x*2.5,display?0:s.y+(s.board>0&&s.jet<=0?.18:0),0);
    hero.root.rotation.y=display?-.31+Math.sin(clock*.6)*.17:Math.PI+(s.lane-s.x)*.16;
    jetpack.visible=!display&&s.jet>0;jetpack.position.set(s.x*2.5,s.y+1.42,.31);
    const slide=!display&&s.slide>0;hero.body.position.y=display?.018*Math.sin(clock*2):slide?-.42:s.y>.18?.02:Math.abs(Math.cos(phase))*.055;
    hero.body.rotation.x=display?0:slide?1.12:.12;
    hero.body.rotation.z=display?-.035:(s.lane-s.x)*.15;
    for(let i=0;i<2;i++){const leg=Math.sin(phase+(i?Math.PI:0)),arm=-leg;
      hero.legs[i].rotation.x=display?(i?.09:-.07):slide?-.99:s.board>0?-.24:s.y>.5?(i?.65:-1.08):leg*.92;
      hero.knees[i].rotation.x=display?.08:slide?1.55:s.board>0?.57:s.y>.5?1.18:.18+Math.max(0,-leg)*1.16;
      hero.arms[i].rotation.x=display?(i?.19:-.14)+Math.sin(clock*2+i)*.04:slide?-.67:arm*.72-.18;
      hero.arms[i].rotation.z=display?(i?.10:-.10):s.board>0?(i?.96:-.96):(i?.12:-.12);
      hero.elbows[i].rotation.x=display?-.25:slide?-.5:-.86;
    }
    hero.head.rotation.x=slide?-.64:-.05;hero.head.rotation.y=display?.12:Math.sin(phase)*.03;
    board.visible=!display&&s.board>0&&s.jet<=0;board.position.set(s.x*2.5,.1+s.y,0);board.rotation.z=(s.lane-s.x)*.22;
    shadow.position.set(display?0:s.x*2.5,display?.041:(s.roof?3.08:.21),.05);shadow.scale.set(display?.62:.52,1,display?.34:.33);shadow.visible=display||s.y<3.35;
  }
  function flatDraw(s,mode){const c=flat,w=c.canvas.width,h=c.canvas.height,q=World.zones[zone];c.clearRect(0,0,w,h);const horizon=h*.34;
    function proj(x,d,y=0){const k=7.5/(d+7.5);return [w/2+x*w*.158*k,horizon+(h*.83-horizon)*k-y*h*.087*k,k];}
    const poly=(points,col)=>{c.fillStyle=col;c.beginPath();points.forEach(([x,y],i)=>i?c.lineTo(x,y):c.moveTo(x,y));c.closePath();c.fill();};
    for(let i=-6;i<7;i++){const x=i*w*.102;c.fillStyle=q.building;c.fillRect(w*.5+x,horizon-h*(.03+Math.abs(Math.sin(i*8))*.06),w*.084,h*.11);}
    for(let l=-1;l<=1;l++){for(let d=85-(s.dist%1.5);d>-2;d-=1.5)poly([proj(l*2.5-.94,d),proj(l*2.5+.94,d),proj(l*2.5+.94,d+.25),proj(l*2.5-.94,d+.25)],'#765a57');for(const off of [-.69,.69])poly([proj(l*2.5+off,-2),proj(l*2.5+off+.10,-2),proj(l*2.5+off+.1,85),proj(l*2.5+off,85)],'#e0c7a8');}
    const objects=s.objects.filter(o=>o.d>-2&&o.d<85&&!o.gone).sort((a,b)=>b.d-a.d);
    for(const o of objects){const [x,y,k]=proj(o.lane*2.5,o.d,o.height||0);c.fillStyle=({coin:'#ffce4c',train:'#23798a',low:'#ee6950',high:'#ee6950',ramp:'#daa56a',magnet:'#db5790',double:'#30bfa3',jet:'#e49447',spring:'#59b487'})[o.kind];
      if(['coin','magnet','double','jet','spring'].includes(o.kind)){c.beginPath();c.arc(x,y,w*.044*k,0,Math.PI*2);c.fill();c.strokeStyle='#ffeca0';c.stroke();}
      else{let hh=h*k*(o.kind==='train'?.26:.092);c.fillRect(x-w*.145*k,y-hh-(o.kind==='high'?h*.12*k:0),w*.29*k,hh);}
    }
    const [hx,hy]=proj(mode==='shop'?0:s.x*2.5,0,s.y);c.fillStyle='#222e47';const size=mode==='shop'?1.45:1;
    c.save();c.translate(hx,hy);c.scale(size,s.slide>0?.56:size);c.fillStyle='#34425c';for(const dir of [-1,1])c.fillRect(dir*9-5,-27+Math.sin(s.phase)*dir*5,10,26);c.fillStyle='#27364f';c.fillRect(-18,-59,36,35);c.fillStyle='#aaaebe';c.fillRect(-16,-60,32,10);c.fillStyle='#d99c7e';c.beginPath();c.ellipse(0,-73,14,17,0,0,7);c.fill();c.fillStyle='#332e32';c.beginPath();c.ellipse(0,-81,14,9,0,0,7);c.fill();if(mode==='shop'){c.fillStyle='#28262c';c.fillRect(-7,-74,3,2);c.fillRect(4,-74,3,2);}if(flatGear.includes('hat')){c.fillStyle='#217b64';c.fillRect(-13,-92,26,10);c.fillStyle='#f6c96e';c.fillRect(-13,-84,26,2);}
    if(flatGear.includes('bag')&&mode!=='shop'){c.fillStyle='#278a83';c.fillRect(-12,-53,24,20);}
    if(flatGear.includes('scarf')){c.fillStyle='#dc624d';c.fillRect(-11,-61,22,5);}
    if(flatGear.includes('glasses')&&mode==='shop'){c.fillStyle='#314c5a';c.fillRect(-11,-76,22,5);}c.restore();}
  function frame(s,dt,mode){if(mode==='home'||mode==='map')return;clock+=dt;
    setZone(s.zone);if(!renderer){flatDraw(s,mode);return;}
    const display=mode==='shop';
    if(display!==shop){shop=display;resize();}
    platform.visible=display;
    // Wrap each section individually, preserving the three-part environment pattern.
    for(let i=0;i<track.length;i++)track[i].position.z=24-((i*24-(s.dist%(track.length*24))+track.length*24)%(track.length*24));
    if(display){camera.position.set(.04,1.48,4.25);camera.lookAt(0,1.20,0);for(const p of track)p.visible=false;}
    else{camera.position.set(s.x*.62,4.18+Math.min(s.y,3)*.26,6.96);camera.lookAt(s.x*.32,1.40+Math.min(s.y,3)*.27,-7);for(const p of track)p.visible=true;}
    const alive=new Set();if(!display){for(const o of s.objects){if(o.gone||o.d>135)continue;alive.add(o);let v=meshes.get(o);if(!v){v=obj(o);meshes.set(o,v);scene.add(v);}
      v.position.set(o.lane*2.5,o.height||0,-o.d);if(['coin','magnet','double','jet','spring'].includes(o.kind)){v.rotation.y=Math.sin(clock*3+o.seed)*.74;v.position.y+=.075*Math.sin(clock*3+o.seed);}}}
    for(const [o,v] of meshes){if(!alive.has(o)){scene.remove(v);meshes.delete(o);}}
    const chasing=!display&&((s.time<2.8&&s.board<=0)||s.grace>0)&&s.jet<=0;
    inspector.root.visible=chasing;
    if(chasing){
      const retreat=s.grace>0?1-s.grace/2.15:s.time/2.8;
      inspector.root.position.set(s.x*.55-1.45,.03,2.2+retreat*4.2);
      inspector.root.rotation.y=Math.PI;inspector.root.scale.setScalar(.89);
      for(let i=0;i<2;i++){const a=Math.sin(s.phase+(i?Math.PI:0));inspector.legs[i].rotation.x=a*.68;inspector.arms[i].rotation.x=-a*.86;}
    }
    pose(s,dt,mode);renderer.render(scene,camera);
    if(mode==='running'&&dt>.034){if(++slow>95&&pixelRatio>1){pixelRatio=Math.max(1,pixelRatio-.25);renderer.setPixelRatio(pixelRatio);resize();slow=0;}}
    else slow=Math.max(0,slow-1);
  }
  return {frame,clear,dress,setZone,resize};
})();
