// Original sixteen-bar loop. The plucked pentatonic line answers the flute over a syncopated breakbeat.
const Music=(()=>{
  let ctx,master,timer,step=0,next=0,playing=false,enabled=true,noise,volume;
  const bpm=112,tick=60/bpm/4,lead=[0,3,5,7,10,12,15,17];
  const notes=[[0,-1,2,-1,3,-1,-1,2,0,-1,-1,1,2,-1,3,-1],[4,-1,3,2,-1,-1,1,-1,0,-1,1,-1,2,-1,-1,-1],[2,-1,3,-1,5,-1,4,-1,3,-1,2,-1,0,-1,1,-1],[3,-1,-1,2,1,-1,0,-1,-1,-1,0,1,2,-1,-1,-1]];
  const freq=n=>440*Math.pow(2,(n-69)/12);
  function init(){if(ctx)return;const C=window.AudioContext||window.webkitAudioContext;if(!C)return;ctx=new C();master=ctx.createGain();master.gain.value=.37;const limit=ctx.createDynamicsCompressor();master.connect(limit);limit.connect(ctx.destination);noise=ctx.createBuffer(1,ctx.sampleRate*.30,ctx.sampleRate);let a=noise.getChannelData(0);for(let i=0;i<a.length;i++)a[i]=Math.random()*2-1;}
  function tone(f,time,dur,type,gain,slide=0,cut=0){if(!ctx)return;const o=ctx.createOscillator(),g=ctx.createGain();o.type=type;o.frequency.setValueAtTime(f,time);if(slide)o.frequency.exponentialRampToValueAtTime(slide,time+dur*.8);
    g.gain.setValueAtTime(.0001,time);g.gain.exponentialRampToValueAtTime(gain,time+.007);g.gain.exponentialRampToValueAtTime(.0001,time+dur);
    if(cut){let lp=ctx.createBiquadFilter();lp.type='lowpass';lp.frequency.setValueAtTime(cut,time);lp.frequency.exponentialRampToValueAtTime(cut*.32,time+dur);o.connect(lp);lp.connect(g);}else o.connect(g);g.connect(master);o.start(time);o.stop(time+dur+.01);}
  function hit(t,dur,hz,gain){let b=ctx.createBufferSource(),f=ctx.createBiquadFilter(),g=ctx.createGain();b.buffer=noise;f.type='highpass';f.frequency.value=hz;g.gain.setValueAtTime(gain,t);g.gain.exponentialRampToValueAtTime(.001,t+dur);b.connect(f);f.connect(g);g.connect(master);b.start(t);b.stop(t+dur);}
  function beat(k,t){let bar=Math.floor(k/16)%16,s=k%16,root=[50,48,46,48][Math.floor(bar/2)%4];
    if(s===0||s===8||s===(bar%2?14:10))tone(134,t,.19,'sine',.83,43);
    if(s===4||s===12){hit(t,.125,1250,.44);tone(176,t,.099,'triangle',.19,84);}
    if(s%2===0||bar%4===3&&s>12)hit(t+(s%4===2?.014:0),s===14?.09:.043,6200,s%4===0?.12:.20);
    if([0,3,7,10,14].includes(s))tone(freq(root-12+(s===7?7:0)),t,.25,'triangle',.57);
    const note=notes[bar%4][s];if(note>=0){const f=freq(62+lead[note]+(bar>=8&&bar<12?12:0));tone(f,t,.25,'triangle',.20);tone(f*2,t,.11,'sine',.075);if(bar%2===1)tone(f,t+tick*1.5,.12,'sine',.052);}
    if(bar%4===2&&[2,6,11].includes(s))tone(freq(74+lead[s===2?3:s===6?2:0]),t,.39,'sine',.12);
    if(s===2||s===10){tone(freq(root+7),t,.13,'sawtooth',.075,0,1700);tone(freq(root+12),t,.16,'triangle',.085);}
  }
  function schedule(){if(!playing||!enabled||!ctx||ctx.state!=='running')return;if(next<ctx.currentTime-.1)next=ctx.currentTime+.015;while(next<ctx.currentTime+.14){beat(step++,next);next+=tick;}}
  function start(){init();if(!ctx||!enabled)return;ctx.resume().catch(()=>{});playing=true;master.gain.setTargetAtTime(.37,ctx.currentTime,.02);next=ctx.currentTime+.04;if(!timer)timer=setInterval(schedule,50);}
  function stop(){playing=false;clearInterval(timer);timer=0;if(ctx)master.gain.setTargetAtTime(.0001,ctx.currentTime,.025);}
  function set(on){enabled=on;if(!on)stop();}
  function sfx(kind){if(!enabled||!ctx||ctx.state!=='running')return;const t=ctx.currentTime;
    if(kind==='coin'){tone(987,t,.075,'sine',.20);tone(1480,t+.045,.12,'sine',.15);}
    if(kind==='jump')tone(235,t,.15,'sine',.11,540);
    if(kind==='power'){[67,71,74,79].forEach((n,i)=>tone(freq(n),t+i*.048,.15,'triangle',.23));}
    if(kind==='crash'){hit(t,.22,140,.42);tone(126,t,.3,'triangle',.33,42);}
  }
  return {start,stop,set,sfx};
})();
